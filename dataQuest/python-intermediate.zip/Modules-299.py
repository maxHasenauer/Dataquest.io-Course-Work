## 1. Introduction ##

# Stream column for top 5 songs only
top5_streams = [2993988783, 1829621841, 1460802540, 1386258295, 1311243745]

def average(lst):
    return sum(lst)/len(lst)

total_average = average(top5_streams)

## 2. Introduction to Modules ##

top5_streams = [2993988783, 1829621841, 1460802540, 1386258295, 1311243745]
import statistics
average = statistics.mean(top5_streams)

## 3. Loading our data using the CSV module ##

import csv
f = open("top100.csv","r")
music = list(csv.reader(f))

## 4. Understanding the namespace ##

import statistics
print(dir())
print(dir(statistics))

## 5. Cleaning Our Data ##

import csv
f = open("top100.csv","r")
music = list(csv.reader(f))
stream_numbers = []
track_names = []
music = music[1:]
for song in music:
    track_names.append(song[0])
    stream_numbers.append(int(song[3]))