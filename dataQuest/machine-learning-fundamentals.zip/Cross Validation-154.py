## 1. Introduction ##

import numpy as np
import pandas as pd

dc_listings = pd.read_csv("dc_airbnb.csv")
stripped_commas = dc_listings['price'].str.replace(',', '')
stripped_dollars = stripped_commas.str.replace('$', '')
dc_listings['price'] = stripped_dollars.astype('float')
new_index = np.random.permutation(dc_listings.index)
dc_listings = dc_listings.reindex(new_index)
split_one = dc_listings.iloc[:1862].copy()
split_two = dc_listings.iloc[1862:].copy()

## 2. Holdout Validation ##

from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error

train_one = split_one
test_one = split_two
train_two = split_two
test_two = split_one
knn = KNeighborsRegressor()
knn.fit(train_one[['accommodates']],train_one['price'])
predictions = knn.predict(test_one[['accommodates']])
iteration_one_rmse = (mean_squared_error(predictions,test_one['price']))**(1/2)
knn.fit(train_two[['accommodates']],train_two['price'])
predictions = knn.predict(test_two[['accommodates']])
iteration_two_rmse = (mean_squared_error(predictions,test_two['price']))**(1/2)
avg_rmse = numpy.mean([iteration_one_rmse,iteration_two_rmse])

## 3. K-Fold Cross Validation ##

dc_listings.loc[dc_listings.index[0:745], "fold"] = 1
dc_listings.loc[dc_listings.index[745:1490], "fold"] = 2
dc_listings.loc[dc_listings.index[1490:2234], "fold"] = 3
dc_listings.loc[dc_listings.index[2234:2978], "fold"] = 4
dc_listings.loc[dc_listings.index[2978:3723], "fold"] = 5

print(dc_listings['fold'].value_counts())
print("\n Num of missing values: ", dc_listings['fold'].isnull().sum())