## 3. The With Clause ##

WITH playlist_info AS
    (
     SELECT
        p.playlist_id,
        p.name playlist_name,
        t.name track_name,
        (t.milliseconds / 1000) length_seconds
     FROM playlist p
     LEFT JOIN playlist_track pt ON pt.playlist_id = p.playlist_id
     LEFT JOIN track t ON t.track_id = pt.track_id
    )
    
SELECT 
    playlist_id,
    playlist_name,
    COUNT(track_name) number_of_tracks,
    SUM(length_seconds) length_seconds
FROM playlist_info
GROUP BY 1, 2
ORDER BY 1;

## 4. Creating Views ##

CREATE VIEW chinook.customer_gt_90_dollars AS
    SELECT c.* 
    FROM chinook.invoice i 
    INNER JOIN chinook.customer c ON c.customer_id = i.customer_id
    GROUP BY 1
    HAVING SUM(i.total) > 90;
    
SELECT * FROM chinook.customer_gt_90_dollars;

## 5. Combining Rows With Union ##

SELECT
    *
from customer_usa

UNION

SELECT
    *
from customer_gt_90_dollars

## 6. Combining Rows Using Intersect and Except ##

WITH customers_usa_gt_90 AS
    (
     SELECT * FROM customer_usa
        
     INTERSECT
        
     SELECT * FROM customer_gt_90_dollars
    )
    
SELECT
    e.first_name || " " || e.last_name employee_name,
    COUNT(c.customer_id) customers_usa_gt_90
FROM employee e
LEFT JOIN customers_usa_gt_90 c ON c.support_rep_id = e.employee_id
WHERE e.title = "Sales Support Agent"
GROUP BY 1 ORDER BY 1;

## 7. Multiple Named Subqueries ##

WITH
    customers_india AS
    (
        SELECT * FROM customer 
        WHERE country = "India"
    ),
    sum_customers AS
    (
        SELECT c.customer_id, SUM(iv.total) total_purchases FROM customer c
        INNER JOIN invoice iv ON iv.customer_id = c.customer_id
        GROUP BY 1
    )
    
SELECT 
    ci.first_name || " " || ci.last_name customer_name,
    sc.total_purchases
FROM sum_customers sc
INNER JOIN customers_india ci ON ci.customer_id = sc.customer_id
GROUP BY 1
ORDER BY 1;

## 8. Challenge: Each Country's Best Customer ##

WITH 
    total_purchases AS
    (
        SELECT 
        c.customer_id customer_id, 
        SUM(iv.total) total_purchased
        FROM customer c
        INNER JOIN invoice iv ON iv.customer_id = c.customer_id
        GROUP BY 1
    ),
    customer_country_purchases AS
    (
        SELECT 
        c.country country, 
        c.first_name || " " || c.last_name customer_name, 
        c.customer_id customer_id
        FROM customer c
    )
    
SELECT 
    ccp.country,
    ccp.customer_name,
    MAX(tp.total_purchased) total_purchased
FROM customer_country_purchases ccp
INNER JOIN total_purchases tp ON tp.customer_id = ccp.customer_id
GROUP BY 1
ORDER BY 1;