## 2. Geometric Intuition Of Vectors ##

import matplotlib.pyplot as plt
import numpy as np

# This code draws the x and y axis as lines.
plt.axhline(0, c='black', lw=0.5)
plt.axvline(0, c='black', lw=0.5)
plt.xlim(-3,3)
plt.ylim(-4,4)

arrows=[[2,3],[-2,-3],[1,1],[2,2]]
colors=['blue','blue','gold','gold']
for i,ar in enumerate(arrows):
    plt.quiver(0,0,ar[0],ar[1],angles='xy',scale_units='xy',scale=1,color=colors[i])
plt.show()

## 3. Vector Operations ##

# This code draws the x and y axis as lines.
plt.axhline(0, c='black', lw=0.5)
plt.axvline(0, c='black', lw=0.5)
plt.xlim(-4,4)
plt.ylim(-1,4)

plt.quiver(0,0,3,0,angles='xy',scale_units='xy',scale=1)
plt.quiver(3,0,0,3,angles='xy',scale_units='xy',scale=1)
plt.quiver(0,0,3,3,angles='xy',scale_units='xy',scale=1,color='green')

## 4. Scaling Vectors ##

# This code draws the x and y axis as lines.
plt.axhline(0, c='black', lw=0.5)
plt.axvline(0, c='black', lw=0.5)
plt.xlim(0,10)
plt.ylim(0,5)

arrows = [[3,1],
          [6,2],
          [9,3]]
colors = ['blue',
          'green',
          'orange']
for i,ar in enumerate(arrows):
    plt.quiver(0,0,ar[0],ar[1],angles='xy',scale_units='xy',scale=1,color=colors[i])
plt.show()

## 5. Vectors In NumPy ##

import numpy as np

vector_one = np.asarray([
    [1],
    [2],
    [1]
], dtype=np.float32)
vector_two = np.asarray([
    [3],
    [0],
    [1]
], dtype=np.float32)
vector_linear_combination = 2*vector_one + 5*vector_two

## 6. Dot Product ##

vector_one = np.asarray([
    [1],
    [2],
    [1]
], dtype=np.float32)

vector_two = np.asarray([
    [3],
    [0],
    [1]
], dtype=np.float32)

dot_product = np.dot(vector_one[:,0], vector_two)
print(dot_product)

## 7. Linear Combination ##

w = np.asarray([
    [1],
    [2]
], dtype=np.float32)
v = np.asarray([
    [3],
    [1]
], dtype=np.float32)
end_point = v*2 - w*2